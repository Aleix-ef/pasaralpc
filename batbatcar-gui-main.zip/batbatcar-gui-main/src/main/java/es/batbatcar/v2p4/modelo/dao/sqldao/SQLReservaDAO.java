package es.batbatcar.v2p4.modelo.dao.sqldao;

import es.batbatcar.v2p4.exceptions.DatabaseConnectionException;
import es.batbatcar.v2p4.exceptions.ReservaAlreadyExistsException;
import es.batbatcar.v2p4.exceptions.ReservaNotFoundException;
import es.batbatcar.v2p4.modelo.dto.Reserva;
import es.batbatcar.v2p4.modelo.dto.viaje.Viaje;
import es.batbatcar.v2p4.modelo.services.MySQLConnection;
import es.batbatcar.v2p4.modelo.dao.interfaces.ReservaDAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
public class SQLReservaDAO implements ReservaDAO {

	private static final String DATABASE_TABLE = "reservas";

	@Autowired
	private MySQLConnection mySQLConnection;

	@Override
	public Set<Reserva> findAll() {
		String sql = String.format("SELECT * FROM %s", DATABASE_TABLE);
		Set<Reserva> reservas = new HashSet<>();

		Connection connection = mySQLConnection.getConnection();

		try (PreparedStatement ps = connection.prepareStatement(sql)) {

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

			}
		} catch (SQLException e) {
			throw new DatabaseConnectionException(sql + e.getMessage());
		}

		return reservas;
	}

	@Override
	public Reserva findById(String id) {
		String sql = String.format("SELECT * FROM %s WHERE codigoReserva = ? ", DATABASE_TABLE);

		Connection connection = mySQLConnection.getConnection();

		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				
			}

		} catch (SQLException e) {
			throw new DatabaseConnectionException(sql + e.getMessage());
		}
		return null;
	}


	@Override
	public ArrayList<Reserva> findAllByUser(String user) {
		String sql = String.format("SELECT * FROM %s WHERE usuario = ? ", DATABASE_TABLE);

		Connection connection = mySQLConnection.getConnection();

		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, user);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				
			}

		} catch (SQLException e) {
			throw new DatabaseConnectionException(sql + e.getMessage());
		}
		return null;
	}

	@Override
	public ArrayList<Reserva> findAllByTravel(Viaje viaje) {
		throw new RuntimeException("Not yet implemented");
	}

	@Override
	public Reserva getById(String id) throws ReservaNotFoundException {
		throw new RuntimeException("Not yet implemented");
	}

	@Override
	public List<Reserva> findAllBySearchParams(Viaje viaje, String searchParams) {
		throw new RuntimeException("Not yet implemented");
	}

	@Override
	public void add(Reserva reserva) throws ReservaAlreadyExistsException {
		throw new RuntimeException("Not yet implemented");

	}

	@Override
	public void update(Reserva reserva) throws ReservaNotFoundException {
		throw new RuntimeException("Not yet implemented");

	}

	@Override
	public void remove(Reserva reserva) throws ReservaNotFoundException {
		throw new RuntimeException("Not yet implemented");

	}

	@Override
	public int getNumPlazasReservadasEnViaje(Viaje viaje) {
		throw new RuntimeException("Not yet implemented");
	}

	@Override
	public Reserva findByUserInTravel(String usuario, Viaje viaje) {
		throw new RuntimeException("Not yet implemented");
	}
}
