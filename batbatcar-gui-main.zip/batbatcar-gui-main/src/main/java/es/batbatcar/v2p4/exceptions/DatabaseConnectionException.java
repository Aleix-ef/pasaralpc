package es.batbatcar.v2p4.exceptions;

public class DatabaseConnectionException extends RuntimeException {

    public DatabaseConnectionException(String msg) {
        super(msg);
    }

}

